/* ── MyTradingView Service Worker ── */
const CACHE = 'mtv-v1';

const PRECACHE = [
  './',
  './index.html',
  './trades.json',
  './prices_history.json',
  './prices.json',
  './watchlist.json'
];

/* Install: pre-cache app shell */
self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE).then(cache => {
      /* Cache index.html strictly; other files best-effort */
      return cache.addAll(['./index.html']).then(() =>
        Promise.allSettled(PRECACHE.slice(1).map(url => cache.add(url)))
      );
    }).then(() => self.skipWaiting())
  );
});

/* Activate: clean old caches */
self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

/* Fetch: network-first for data files, cache-first for app shell */
self.addEventListener('fetch', e => {
  const url = new URL(e.request.url);
  const isDataFile = /\.(json)$/.test(url.pathname);
  const isSameOrigin = url.origin === self.location.origin;

  if (!isSameOrigin) return; /* Don't intercept CDN / Yahoo Finance */

  if (isDataFile) {
    /* Network-first: always try fresh data, fall back to cache */
    e.respondWith(
      fetch(e.request)
        .then(res => {
          if (res.ok) {
            const clone = res.clone();
            caches.open(CACHE).then(c => c.put(e.request, clone));
          }
          return res;
        })
        .catch(() => caches.match(e.request))
    );
  } else {
    /* Cache-first for HTML/assets: fast load, background refresh */
    e.respondWith(
      caches.match(e.request).then(cached => {
        const fetchFresh = fetch(e.request).then(res => {
          if (res.ok) {
            const clone = res.clone();
            caches.open(CACHE).then(c => c.put(e.request, clone));
          }
          return res;
        });
        return cached || fetchFresh;
      })
    );
  }
});
